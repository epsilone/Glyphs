using UnityEngine;
using System.Collections;

/// <summary>
/// Toolbox TBDragToMove sample
/// See "TB Draggable Sphere" objects and their TBDragToMove settings
/// </summary>
public class ToolboxDragSample : SampleBase
{
    
}